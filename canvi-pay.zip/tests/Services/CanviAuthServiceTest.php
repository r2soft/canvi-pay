<?php

declare(strict_types=1);

namespace R2Soft\Canvi\Tests\Services;

use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use R2Soft\Canvi\CanviClient;
use R2Soft\Canvi\Exceptions\ApiException;
use R2Soft\Canvi\Services\CanviAuthService;

class CanviAuthServiceTest extends TestCase
{
    private CanviClient|MockObject $clientMock;
    private CanviAuthService $authService;

    protected function setUp(): void
    {
        $this->clientMock = $this->createMock(CanviClient::class);
        $this->authService = new CanviAuthService(
            $this->clientMock,
            'test_client_id',
            'test_client_secret',
            '/bt/token',
            null
        );
    }

    public function testGenerateTokenWithDefaultCredentials(): void
    {
        $expectedToken = 'test_token_123';
        $apiKey = 'test_api_key';
        $apiSecret = 'test_api_secret';

        $this->clientMock->method('getApiKey')->willReturn($apiKey);
        $this->clientMock->method('getApiSecret')->willReturn($apiSecret);
        
        $this->clientMock->expects($this->once())
            ->method('authenticate')
            ->with(
                '/bt/token',
                [
                    'client_id' => $apiKey,
                    'private_key' => $apiSecret,
                ],
                null
            )
            ->willReturn($expectedToken);

        $token = $this->authService->generateToken();
        $this->assertSame($expectedToken, $token);
    }

    public function testGenerateTokenWithCustomCredentials(): void
    {
        $expectedToken = 'test_token_456';
        $credentials = [
            'client_id' => 'custom_key',
            'private_key' => 'custom_secret',
        ];

        $this->clientMock->expects($this->once())
            ->method('authenticate')
            ->with(
                '/bt/token',
                $credentials,
                null
            )
            ->willReturn($expectedToken);

        $token = $this->authService->generateToken($credentials);
        $this->assertSame($expectedToken, $token);
    }

    public function testGenerateTokenWithCustomAuthPath(): void
    {
        $expectedToken = 'test_token_789';
        $customPath = '/custom/auth/path';
        
        $authService = new CanviAuthService(
            $this->clientMock,
            $customPath
        );

        $this->clientMock->method('getApiKey')->willReturn('key');
        $this->clientMock->method('getApiSecret')->willReturn('secret');
        
        $this->clientMock->expects($this->once())
            ->method('authenticate')
            ->with(
                $customPath,
                $this->isType('array'),
                null
            )
            ->willReturn($expectedToken);

        $token = $authService->generateToken();
        $this->assertSame($expectedToken, $token);
    }

    public function testGenerateTokenWithCustomExtractor(): void
    {
        $expectedToken = 'extracted_token';
        $apiResponse = ['access_token' => $expectedToken, 'expires_in' => 3600];
        $extractor = fn(array $data) => $data['access_token'] ?? null;
        
        $authService = new CanviAuthService(
            $this->clientMock,
            '/bt/token',
            $extractor
        );

        $this->clientMock->method('getApiKey')->willReturn('key');
        $this->clientMock->method('getApiSecret')->willReturn('secret');
        
        $this->clientMock->expects($this->once())
            ->method('authenticate')
            ->with(
                '/bt/token',
                $this->isType('array'),
                $extractor
            )
            ->willReturn($expectedToken);

        $token = $authService->generateToken();
        $this->assertSame($expectedToken, $token);
    }

    public function testGenerateTokenWithInvalidCredentials(): void
    {
        $this->clientMock->method('getApiKey')->willReturn('');
        $this->clientMock->method('getApiSecret')->willReturn('');
        
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Credenciais ausentes: informe client_id e private_key, ou configure no CanviClient.');
        
        $this->authService->generateToken();
    }

    public function testGenerateTokenWithApiException(): void
    {
        $this->clientMock->method('getApiKey')->willReturn('key');
        $this->clientMock->method('getApiSecret')->willReturn('secret');
        
        $this->clientMock->expects($this->once())
            ->method('authenticate')
            ->willThrowException(new ApiException('Authentication failed', 401));
        
        $this->expectException(ApiException::class);
        $this->expectExceptionMessage('Authentication failed');
        $this->expectExceptionCode(401);
        
        $this->authService->generateToken();
    }
}
